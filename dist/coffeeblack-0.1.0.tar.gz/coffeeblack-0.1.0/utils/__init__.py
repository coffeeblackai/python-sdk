"""
Utility functions for the CoffeeBlack SDK
""" 