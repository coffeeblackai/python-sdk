"""
Utility modules for the CoffeeBlack SDK
"""

from . import debug, window, screenshot, app_manager 